clear all
clc
close all
format compact
if length(instrfind) > 0
    fclose(instrfind);
    delete(instrfind);
end
arduino=serial('COM8','BaudRate',9600);
fopen(arduino);
fread(arduino, 1);
%test values
% rowVals = linspace(100,400,6);
% colVals = linspace(550,50,6);
%color values
fprintf('Click once on the target color rectangle then hit Enter');
target = imread('blue_a1.bmp');
targetRGB = ColorPicker(target)
[centroidRow, centroidCol, modImageArray] = FindAllTargetCentroids(target, targetRGB);
centroidRow
centroidCol

figure
image(modImageArray)
axis image
hold on
plot(centroidCol, centroidRow, 'wx')
hold off
rowVals = centroidRow;
colVals = centroidCol;
encoderPos= 1:length(rowVals);
xTargetMilli = 1:length(rowVals);
xTargetHB = 1:length(rowVals);
xTargetLB = 1:length(rowVals);
%convert row vals to mm
for i = 1:length(rowVals)
    %SIX MAY BE BETWEEN FIVE AND SIX
    encoderPos(i) = (rowVals(i)./10) - 6;
end
%set distance offset
for i = 1:length(rowVals)
    xTargetMilli(i) = colVals(i)+650;
end
%create High and Low bytes for col vals
for i = 1:length(rowVals)
    xTargetHB(i) = floor(xTargetMilli(i)./256);
end
for i = 1:length(rowVals)
    xTargetLB(i) = xTargetMilli(i)-(256.*xTargetHB(i));
end
%send data to romeo
for i = 1:length(rowVals)
    vals = [encoderPos(i), xTargetHB(i), xTargetLB(i)];
    fwrite(arduino, vals);
    while (arduino.BytesAvailable == 0)
        %fprintf('Waiting\n')
    end
    msg = fscanf(arduino);
    msg = msg(1:end-2);
    disp(msg)
end

%infinite scanning loop
while (true)
    msg = fscanf(arduino);
    if ~isempty(msg)
        msg = msg(1:end-2);
        if isempty(msg)
            break
        end
        disp(msg)
    end
end

fclose(arduino);
delete(arduino);
clear;