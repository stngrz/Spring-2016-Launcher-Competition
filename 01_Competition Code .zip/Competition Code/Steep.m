function [ thetaL ] = Steep( d, v0, xTarget)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


[ maxXLand, maxXLandAngle ] = ProjectileRange( d, v0 );
 angleL = linspace(maxXLandAngle, 90,10000);
 xLand = LandingDistance( d, v0, angleL );
 vec1 = abs(xLand-xTarget);
 [vec2,loc] = min(vec1);
 thetaL = angleL(loc);
 
end

