function [ pixelVal ] = ColorPicker( RGBarray )

myImage = RGBarray ;
figure
image(myImage)
[x,y] = ginput;
c = round(x);
r = round(y);
R = myImage(r,c,1);
G = myImage(r,c,2);
B = myImage(r,c,3);
pixelVal = [R G B];
end

