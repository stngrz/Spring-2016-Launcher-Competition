function [ sErrors ] = CompareProjectileData( v0, d, expThetaL, expXDist )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

xLandTheory  = LandingDistance( d, v0, expThetaL );
 sErrors  = SumOfSquaredErrors( expXDist, xLandTheory );
end

