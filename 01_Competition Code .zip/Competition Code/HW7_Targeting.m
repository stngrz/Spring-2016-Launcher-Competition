% % % % % % % % % % % % 
% Eric Bellan/Jacob Kolb
% u0793886/u0771725
% ME EN 1010 Lab Section 3
% HW7_Targeting
% Due March 3,2016
% % % % % % % % % % % %
 clear
 clc
 close all
 format compact
 %% test steep1
%  load d_vector
%  v0 = 3.2;
%  xTarget = .95;
%  thetaL  = Steep( d, v0, xTarget)
  %% test 2
 
  load d_vector
 v0 = 2.9953;
 xTarget = [0.75, 0.9, 1.05,1.2] ;
 for k = 1:length(xTarget) 
thetaL  = Steep( d, v0, xTarget(k));
 fprintf('To hit a target at %.2f m the lanuch angle should be %2.2f degrees\n',xTarget(k),thetaL)
end
   
 %% test theta servo
%  load H_vector
%  thetaL = 63.9;
%  offsets = [0 14];
%  thetaS  = ThetaServo( H, thetaL, offsets )
 
 %%test 2
 
 load H_vector
 thetaL = [71.4, 63.9, 53.6] ;
 offsets =[16.9690 13.9605];
 for k = 1:length(thetaL)
    thetaS  = ThetaServo( H, thetaL(k), offsets );
fprintf('Use servo angle %2.2f degrees to get a lanuch angle should be %2.2f degrees\n',thetaS,thetaL(k))
end
 %% part 3
 load d_vector
 load H_vector
 xTarget = [0.75, 0.9, 1.05, 1.2];
 v0 = 2.9953;
 offsets =[16.9690 13.9605];
 for k = 1:length(xTarget)
     thetaL  = Steep( d, v0, xTarget(k));
     thetaS  = ThetaServo( H, thetaL, offsets );
     fprintf('Target distance = %.2f m --> Launch angle =  %2.2f degrees --> Servo angle = %2.2f degrees\n', xTarget(k),thetaL,thetaS)
 end
 