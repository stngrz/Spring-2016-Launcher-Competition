function [ thetaL ] = ThetaLaunch( L, thetaS, offsets )
% computes launch angle for a givven set of lengths and servomotor angles
% Inputs: a vector of lengths (m), a vector of setup angles (degrees), a
% vector of servomotor angles(degrees)
% Outputs: a vector of launch angles (degrees)
thetaS0 = offsets(1);
thetaL0 = offsets(2);
theta2 = 180 - thetaS + thetaS0;
theta4  = ThetaFour( L, theta2 );
thetaL = 180 - theta4 + thetaL0;
if (nargout == 0)
    plot(thetaS, thetaL)
    title('Cannon Fourbar Kinematices')
    xlabel('ServomotorAngle Angle [deg]')
    ylabel('Launch Angle [deg]')

end

