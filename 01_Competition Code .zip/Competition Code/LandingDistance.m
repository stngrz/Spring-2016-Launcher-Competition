function [ xLand ] = LandingDistance( d, v0, theta )
%computes the landing distance of a projectile for given inital velocity,
%angle and launch structure lengths
% Inputs: a vector of d(m), v0(m/s), theta(degrees)
% Output: xLand(m)

g = 9.81;
[ x0, y0 ] = InitalCords( d, theta);
[ vx0, vy0 ] = InitalVelocity( v0, theta);
a = -.5*g;
b = vy0;
c = y0;
[ negRoot, posRoot ] = Quadratic( a, b, c );
tland = negRoot;
xLand = tland.*vx0 +x0;


end

