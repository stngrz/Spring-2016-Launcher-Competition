function [ launchAngle, avgExpData ] = ProjectileData( filename )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
data = xlsread(filename);
data = data([1:end],[1, 3, 4, 5]);
dist = data(:,3:end);
avgDistExp = mean(dist, 2);
if (nargout == 0)
    plot(data(:,1), avgDistExp, 'o')
    title('Ping Pong Ball Projectile Data')
    xlabel('Launch Angle [deg]')
    ylabel('Horizontal Distance Traveled [m]')
else
    avgExpData = avgDistExp;
    launchAngle = data(:,1);

end

