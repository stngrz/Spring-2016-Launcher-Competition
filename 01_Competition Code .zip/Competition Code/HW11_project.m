%%%%%%%%%%
% Eric Bellan and Jacob Kolb
% u0793886
% ME EN 1010 Lab Section3
% HW11_Project
% Due April 12, 2016
%%%%%%%%%
clear 
clc
close all

% %% color picker
% test1 = imread('blue_A1.bmp');
% pixelVal = ColorPicker( test1 );
% 
% %% find target centroid
% test2 = imread('blue_A1.bmp');
% fprintf('Click on the target rectangle');
% targetRGB = ColorPicker(test2)
% [centroidRow, centroidCol, modImageArray] = FindTargetCentroid(test2, targetRGB);
% centroidRow;
% centroidCol;
% 
% figure
% image(modImageArray)
% axis image

%% test find all target centroids
fprintf('Click on the target color rectangle then hit Enter');
target = imread('blue_A1.bmp');
targetRGB = ColorPicker(target)
[centroidRow, centroidCol, modImageArray] = FindAllTargetCentroids(target, targetRGB);
centroidRow
centroidCol

figure
image(modImageArray)
axis image
hold on
plot(centroidCol, centroidRow, 'wx')

