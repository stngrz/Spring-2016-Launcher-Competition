function [ negRoot, posRoot ] = Quadratic( a, b, c )
% this function computes the positive and negative roots of the quadratic formula using the coeficints for a
% quadratic polynomial
% if the function will output a complex number than an error message is
% displayed and the program is ended

root = b.^2 - 4*a.*c;
if(root >= 0)
    negRoot = (-b-sqrt(b.^2-4*a.*c))./(2*a);
    posRoot = (-b+sqrt(b.^2-4*a.*c))./(2*a);
else
    error('the coeficints will yield a complex root')
end

