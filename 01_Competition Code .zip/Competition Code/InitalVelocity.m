function [ v0x, v0y  ] = InitalVelocity(v0, theta)
%computes the x and y components of the inital velocity 
% inputs: inital velocity (m/s), launch angle (degrees)
% outputs: inital horizontal velocity(m/s), inital vertical velocity(m)
v0x = v0.*cosd(theta);
v0y = v0.*sind(theta);

end

