function [ x0, y0 ] = InitalCords( d, theta )
%this function computes the inital position of a projectile
% inputs: a vector of 3 distance (m), angle between d2 and
% the horizontal
% outputs: x cordinate of output(m), y cordinate of output(m) 

d1 = d(1);
d2 = d(2);
d3 = d(3);
x0 = d2.*cosd(theta) - d3.*sind(theta);
y0 = d1 +d2.*sind(theta) + d3.*cosd(theta);

end

