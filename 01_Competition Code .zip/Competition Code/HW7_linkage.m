% % % % % % % % % % % % 
% Eric Bellan/Jacob Kolb
% u0793886/u0771725
% ME EN 1010 Lab Section 3
% HW7_linkage
% Due March 3,2016
% % % % % % % % % % % %
 clear
 clc
 close all
 format compact

 %% part 1
 load L_vector
 thetaS = [0:.1:180];
 offsets = [0, 14];
 filename = 'v3_team19_linkage data.xlsx';
 data = xlsread(filename);
 thetaLExp = data(:,1);
 thetaSExp = data(:,2);
 sErrors  = CompareLinkageData( offsets, L, thetaSExp, thetaLExp );
 
 %% part 2
 load L_vector
 filename = 'v3_team19_linkage data.xlsx';
 data = xlsread(filename);
 thetaLExp = data(:,1);
 thetaSExp = data(:,2);
 handCompLink = @(offsets) CompareLinkageData( offsets,L, thetaSExp, thetaLExp );
 optimal_offsets = fminsearch(handCompLink,[0 14],[ ])
 sErrors  = CompareLinkageData( optimal_offsets, L, thetaSExp, thetaLExp );
 hold on
 
 thetaL = ThetaLaunch( L, thetaSExp, optimal_offsets);
 plot(thetaSExp, thetaL, 'b-')
 plot(thetaSExp, thetaLExp, 'rx')
 title('Cannon Fourbar Kinematics')
 xlabel('Servomotor Angle [degrees]')
 ylabel('Launch Angle [degrees]')
 message1 = sprintf('Launch angle offset = %2.2f degrees \n', optimal_offsets(1));
 text(20,85, message1)
message2 = sprintf('Servo angle offset = %2.2f degrees \n', optimal_offsets(2));
 text(20,75, message2)
message3 = sprintf('SSE = %2.4f \n', sErrors);
 text(20,65, message3)
legend('theory', 'experimental', 'Location','southeast')