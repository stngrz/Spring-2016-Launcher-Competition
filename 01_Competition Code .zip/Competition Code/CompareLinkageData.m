function [ sErrors ] = CompareLinkageData( offsets, L, thetaS, expThetaL )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

thetaLTheory  = ThetaLaunch( L, thetaS, offsets );
sErrors  = SumOfSquaredErrors( expThetaL, thetaLTheory );
end

