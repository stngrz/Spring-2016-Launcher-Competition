function [  centroidRow, centroidCol, modImageArray ] = FindAllTargetCentroids( RGBarray, RGBtarget )
 modImageArray = RGBarray;
 for i =1:6
     [rowTarget, colTarget, modImageArray] = FindTargetCentroid(modImageArray, RGBtarget);
     centroidRow(i) = rowTarget;
     centroidCol(i) = colTarget;
 end
 

end

