% % % % % % % % % % % % 
% Eric Bellan/Jacob Kolb
% u0793886/u0771725
% ME EN 1010 Lab Section 3
% HW7_Projectile
% Due March 3,2016
% % % % % % % % % % % %
 clear
 clc
 close all
 format compact

 %% part 1
  filename = 'v4_Launch_Angles_Cannon_Servo.xlsx';
 [ launchAngle, avgExpData ] = ProjectileData( filename );
 ProjectileData( filename );
 hold on
 load d_vector;
 v0 = 3.2;
 data = xlsread(filename);
 theta = data(:,1);
 xLand  = LandingDistance( d, v0, theta );
 plot(theta, xLand)
 legend('experiment', 'theory')
 sErrors = CompareProjectileData( v0, d, launchAngle, avgExpData );
 message = sprintf('SSE for v0 = %1.1f m/s is %f \n', v0, sErrors);
 text(30,.6, message)
 hold off
 %% part 2
  filename = 'v4_Launch_Angles_Cannon_Servo.xlsx';
 [ launchAngle, avgExpData ] = ProjectileData( filename );
 load d_vector
 handComp = @(v0) CompareProjectileData(v0,d,launchAngle,avgExpData);
 minV0 = 2.5;
 maxV0 = 3.5;
 optimal_v0 = fminbnd(handComp, minV0, maxV0, [])
 
 %% part 3
 filename = 'v4_Launch_Angles_Cannon_Servo.xlsx';
 [ launchAngle, avgExpData ] = ProjectileData( filename );
 ProjectileData( filename );
 hold on
 load d_vector;
 
 handComp = @(v0) CompareProjectileData(v0,d,launchAngle,avgExpData);
 minV0 = 2.5;
 maxV0 = 3.5;
 optimal_v0 = fminbnd(handComp, minV0, maxV0, []);
 
  data = xlsread(filename);
 theta = data(:,1);
 xLand  = LandingDistance( d, optimal_v0, theta );
 plot(theta, xLand)
 legend('experiment', 'theory')
 sErrors = CompareProjectileData( optimal_v0, d, launchAngle, avgExpData );
 message = sprintf('The SSE is %1.4f for an inital velocity of %1.2f m/s\n', sErrors, optimal_v0);
 text(25,.5, message)
 hold off
 