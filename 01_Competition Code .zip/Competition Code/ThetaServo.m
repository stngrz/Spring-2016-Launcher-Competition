function [ thetaS ] = ThetaServo( H, thetaL, offsets )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here


 
thetaS0 = offsets(1);
thetaL0 = offsets(2);
theta2 = thetaL - thetaL0;
theta4 = ThetaFour( H, theta2 );
thetaS = theta4 + thetaS0;
 
end

