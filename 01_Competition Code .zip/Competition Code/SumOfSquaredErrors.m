function [ SSE ] = SumOfSquaredErrors( x, y )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
L = length(x);
SSEApprox = 0;
for n = [1:L]
    approx = (x(n)- y(n)).^2;
    SSEApprox = approx + SSEApprox;
end
SSE = SSEApprox;
end

